//tv_main.cc
//main de mi programa
#include<iostream>
#include<string>
#include "tv.h"
#include "../product/product.h"

int main(void){
    Tv t("44XX", "Tv", 44.55, 
            "Distribuciones A", "Distribuciones B");
}