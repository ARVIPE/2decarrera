//person_main.cc
//main de mi programa
#include <iostream>
#include <string>
#include "computer.h"
#include "../product/product.h"

int main(void){
    Computer computer("32XXX", ComputerType::Laptop, "Legion", 803.22, "Lenovo", "Mediamark");
   
    //std::cout<<persona.get_full_address();
   // std::cout<<"id: " << persona.get_id();
}