// product.cc
// Para metodos de producto
