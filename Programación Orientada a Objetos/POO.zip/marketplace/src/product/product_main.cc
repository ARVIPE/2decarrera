//product_main.cc
//main de mi programa
#include <iostream>
#include <string>
#include "product.h"

int main(void){
    Product producto("XX52", "croquetas", 5.2, "hacendado", "paco");
    
}