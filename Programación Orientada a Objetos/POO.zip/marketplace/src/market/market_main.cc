// basket_main.cc
// main de mi programa
#include <iostream>
#include <string>
#include "market.h"


int main(void)
{
    // Basket b("bb1");
    // //Client c("XXX1", "Arturo", "Vicente", "Escriba Lubna", "Cordoba", "Cordoba", "España", 2002);
    // Client p("44XX", "Carlos", "Gutierrez", "C/ Mesa 1", "Aguilar", "Sevilla", "España", 2000, 1);

    // std::cout << p.get_town();
    Market m("Esto es un slogan");
    std::cout << m.get_slogan();


   //std::cout << c.get_id();
    


   
}
